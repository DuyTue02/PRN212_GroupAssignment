﻿using BLL.Services;
using DAL.Entities;
using System.Windows;
using System.Windows.Controls;
using System; 
using System.Collections.Generic;

namespace GroupAssignment
{
    public partial class VehicleManagementWindow : Window
    {
        private readonly VehicleService _vehicleService;
        private User _currentUser;
        public VehicleManagementWindow(User loggedInUser)
        {
            InitializeComponent();
            _vehicleService = new VehicleService();
            _currentUser = loggedInUser;
            this.Title = $"Vehicle Management (Welcome, {_currentUser.FullName}!)";
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadVehicles();
            CheckPermissions();
        }
        private void LoadVehicles()
        {
            try
            {
                dgVehicles.ItemsSource = _vehicleService.GetVehicles();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading vehicles: " + ex.Message);
            }
        }

        private void CheckPermissions()
        {
            if (_currentUser.Role != "Admin")
            {
                btnDelete.IsEnabled = false;
            }
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Vehicle vehicle = GetVehicleFromForm(isAddNew: true);
                if (vehicle == null) return;

                _vehicleService.AddVehicle(vehicle);
                MessageBox.Show("Thêm xe thành công!");
                LoadVehicles();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (dgVehicles.SelectedItem == null)
            {
                MessageBox.Show("Vui lòng chọn xe để cập nhật.");
                return;
            }

            try
            {
                Vehicle vehicle = GetVehicleFromForm(isAddNew: false);
                if (vehicle == null) return;

                _vehicleService.UpdateVehicle(vehicle);
                MessageBox.Show("Cập nhật xe thành công!");
                LoadVehicles();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi cập nhật: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgVehicles.SelectedItem is Vehicle selectedVehicle)
            {
                if (MessageBox.Show("Bạn có chắc muốn xóa xe này?", "Xác nhận", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    try
                    {
                        _vehicleService.DeleteVehicle(selectedVehicle);
                        MessageBox.Show("Xóa xe thành công!");
                        LoadVehicles();
                        ClearForm();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi khi xóa (xe có thể đang được thuê): " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn xe để xóa.");
            }
        }
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string keyword = txtSearch.Text;
            if (string.IsNullOrWhiteSpace(keyword))
            {
                MessageBox.Show("Vui lòng nhập Biển số hoặc Model để tìm.");
                return;
            }
            dgVehicles.ItemsSource = _vehicleService.SearchVehicles(keyword);
        }

        private void btnShowAll_Click(object sender, RoutedEventArgs e)
        {
            txtSearch.Text = "";
            LoadVehicles();
        }
        private void ClearForm()
        {
            txtVehicleID.Text = "";
            txtLicensePlate.Text = "";
            txtModel.Text = "";
            txtStatus.Text = "Available";
            txtStationID.Text = "";
            dgVehicles.SelectedItem = null;
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            ClearForm();
        }
        private void dgVehicles_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgVehicles.SelectedItem is Vehicle selectedVehicle)
            {
                txtVehicleID.Text = selectedVehicle.VehicleId.ToString();
                txtLicensePlate.Text = selectedVehicle.LicensePlate;
                txtModel.Text = selectedVehicle.Model;
                txtStatus.Text = selectedVehicle.Status;
                txtStationID.Text = selectedVehicle.CurrentStationId?.ToString() ?? "";
            }
        }
        private Vehicle GetVehicleFromForm(bool isAddNew)
        {
            int? stationId = null;
            if (!string.IsNullOrEmpty(txtStationID.Text))
            {
                if (int.TryParse(txtStationID.Text, out int id))
                {
                    stationId = id;
                }
                else
                {
                    MessageBox.Show("Station ID phải là số.");
                    return null;
                }
            }

            Vehicle vehicle;
            if (isAddNew)
            {
                vehicle = new Vehicle();
            }
            else
            {
                vehicle = dgVehicles.SelectedItem as Vehicle;
                if (vehicle == null) return null;
            }
            vehicle.LicensePlate = txtLicensePlate.Text;
            vehicle.Model = txtModel.Text;
            vehicle.Status = txtStatus.Text;
            vehicle.CurrentStationId = stationId;

            return vehicle;
        }
    }
}